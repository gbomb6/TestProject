﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FunctionApp1
{
    public class Calculations
    {
        public double GetLoanLikelihood(decimal requestedLoanAmount)
        {
            if (requestedLoanAmount <= 0m)
            {
                return 0;
            }

            // 100 percent likelihood(initial value) minus the probability expressed from the quotient of howmuch and the total maximum amount($10000)
            var likelihood = Math.Round(100 * ((10000 - (double)requestedLoanAmount) / 10000));

            return likelihood;
        }

        public DateTime GetExpectedLoanDate(DateTime requestedDate)
        {
            // Funds will be made available 10 business days after day of submission
            // Business days are weekdays, there are no holidays that are applicable
            // Cast DayOfWeek enum to integer to get enum numeric value
            var dayOfTheWeek = (int)requestedDate.DayOfWeek;
            DateTime expectedDate;

            // If day of the week is Sunday(7) add 15 days to account for 10 business days plus one day so loan doesn't fall on weekend, 
            // if Saturday add 16 days, otherwise add an even two weeks
            if (dayOfTheWeek == 0)
            {
                expectedDate = requestedDate.AddDays(15);
            }
            else if (dayOfTheWeek == 6)
            {
                expectedDate = requestedDate.AddDays(16);
            }
            else
            {
                expectedDate = requestedDate.AddDays(14);
            }

            return expectedDate;
        }
    }
}
