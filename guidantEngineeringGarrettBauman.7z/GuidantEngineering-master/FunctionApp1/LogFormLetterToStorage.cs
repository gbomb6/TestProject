using System;
using System.Threading.Tasks;
using FunctionApp1.Messages;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage.Table;

namespace FunctionApp1
{
    public class LogFormLetterToStorage
    {
        [FunctionName("LogFormLetterToStorage")]
        public async Task Run([QueueTrigger("outputletter", Connection = "AzureWebJobsStorage")]FormLetter myQueueItem,
            [Table("letters")] IAsyncCollector<LetterEntity> letterTableCollector,
            ILogger log)
        {
            // Map FormLetter message to LetterEntity type and save to table storage
            var letter = new LetterEntity(myQueueItem);

            await letterTableCollector.AddAsync(letter);

            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");
        }
    }

    public class LetterEntity : TableEntity 
    {
        public LetterEntity(FormLetter form)
        {
            PartitionKey = DateTime.UtcNow.Ticks.ToString();
            RowKey = DateTime.UtcNow.Ticks.ToString();
            Heading = form.Heading;
            Likelihood = form.Likelihood;
            ExpectedDate = form.ExpectedDate;
            RequestedDate = form.RequestedDate;
            Body = form.Body;
        }

        public string Heading { get; set; }
        public double Likelihood { get; set; }
        public DateTime ExpectedDate { get; set; }
        public DateTime RequestedDate { get; set; }
        public string Body { get; set; }
    }
}
