﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace FunctionApp1.TestSuite
{
    [TestFixture()]
    public class CalculationTests
    {
        private const decimal noLoanAmount = 0m;
        private const decimal lowLoanAmount = 1300m;
        private const decimal midLoanAmount = 4700m;
        private const decimal highLoanAmount = 9600m;

        private DateTime sunday = new DateTime(2020, 02, 16);
        private DateTime monday = new DateTime(2020, 02, 17);
        private DateTime tuesday = new DateTime(2020, 02, 11);
        private DateTime friday = new DateTime(2020, 02, 14);
        private DateTime saturday = new DateTime(2020, 02, 15);

        [Test]
        public void GetLoanLikelihoodTest()
        {
            var calculations = new Calculations();

            Assert.IsTrue(calculations.GetLoanLikelihood(noLoanAmount) == 0, "No loan amount should not return 100% because there is no reason to approve a $0.00 loan");
            Assert.IsTrue(calculations.GetLoanLikelihood(lowLoanAmount) == 87, "No match searchString should return 0 results");
            Assert.IsTrue(calculations.GetLoanLikelihood(midLoanAmount) == 53, "No match searchString should return 0 results");
            Assert.IsTrue(calculations.GetLoanLikelihood(highLoanAmount) == 4, "No match searchString should return 0 results");



            Assert.IsTrue(calculations.GetExpectedLoanDate(sunday).Date == new DateTime(2020, 03, 02), "Sunday requested loan date should return the Monday fifteen days later");
            Assert.IsTrue(calculations.GetExpectedLoanDate(monday).Date == new DateTime(2020, 03, 02), "Sunday requested loan date should return the Monday fifteen days later");
            Assert.IsTrue(calculations.GetExpectedLoanDate(tuesday).Date == new DateTime(2020, 02, 25), "Sunday requested loan date should return the Monday fifteen days later");
            Assert.IsTrue(calculations.GetExpectedLoanDate(friday) == new DateTime(2020, 02, 28), "Sunday requested loan date should return the Monday fifteen days later");
            Assert.IsTrue(calculations.GetExpectedLoanDate(saturday) == new DateTime(2020, 03, 02), "Sunday requested loan date should return the Monday fifteen days later");

        }
    }
}
