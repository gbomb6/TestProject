using System;
using System.Threading.Tasks;
using FunctionApp1.Messages;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;

namespace FunctionApp1
{
    public class CalculateDatesAndAmountsFunction
    {
        [FunctionName("CalculateDatesAndAmountsFunction")]
        public async Task Run([QueueTrigger("messagetomom", Connection = "AzureWebJobsStorage")]MessageToMom myQueueItem, 
            [Queue("outputletter")] IAsyncCollector<FormLetter> letterCollector,
            ILogger log)
        {
            log.LogInformation($"{myQueueItem.Greeting} {myQueueItem.HowMuch} {myQueueItem.HowSoon}");
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");

            // Parse flattery list into comma separated string
            if (myQueueItem.Flattery != null && myQueueItem.Flattery.Count > 0)
            {
                // Flattery list cannot be null
                var flattery = string.Join(",", myQueueItem.Flattery);
            }

            // Populate Header with salutation comma separated string and "Mother"
            var form = new FormLetter();
            form.Heading = myQueueItem.Greeting + ",\r\nMother ";
            form.RequestedDate = myQueueItem.HowSoon ?? DateTime.UtcNow;

            var calculations = new Calculations();
            form.Likelihood = calculations.GetLoanLikelihood(myQueueItem.HowMuch);
            form.ExpectedDate = calculations.GetExpectedLoanDate(form.RequestedDate);

            form.Body = $"Really need help: I need ${myQueueItem.HowMuch} by {form.ExpectedDate}";

            await letterCollector.AddAsync(form);
        }   
    }
}
